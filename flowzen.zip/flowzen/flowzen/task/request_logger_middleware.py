import time, datetime

class Request_logger_middleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):

        start_time = time.time()
        now = datetime.datetime.now()
        response = self.get_response(request)
        duration = time.time() - start_time
        print(f"Request processed in {duration:.4f} seconds and the timestamp is {now}")

        return response