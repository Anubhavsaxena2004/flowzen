from django.db import models

# Create your models here.
class Task(models.Model):
    task = models.CharField(max_length = 200)
    description = models.TextField()
    status = models.CharField(max_length = 20)
    priority = models.CharField(max_length = 20, default = "pending")
    date = models.DateField()

