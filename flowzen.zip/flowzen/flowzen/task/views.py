from django.shortcuts import render
from django.http import HttpResponse,JsonResponse
import datetime
from django.views.decorators.csrf import csrf_exempt
from .models import Task

ALLOWED_PRIORITY = ['Low', 'Medium', 'High'] 
ALLOWED_STATUSES = ['In_Progress', 'Pending', 'Completed']

ALLOWED_TRANSACTIONS = {
    'Pending' : ['In_progress'],
    'In_progress' : ['Pending', 'Completed'],
    'Completed' : []
}

def to_dict(task):
    return {
        "id": task.id,
        "title": task.title,
        "description": task.description,
        "priority": task.priority,
        "status": task.status,
        "dueDate": str(task.due_date),
    }


def is_valid(request):
    def get(self, request):
        id = Task.i
        task = Task.objects.all()
        description = Task.objects.all()

    return HttpResponse("this function is to check if json data sent is valid or not")

def task(request):
    return HttpResponse("this function is for reading and showing the tasks")

def task_operations(request):
    return HttpResponse("this function will be used for the operations")

def task_status(request):
    return HttpResponse("this fucntion is to show status of task")

def landing(request):
    return HttpResponse("this is the landing page")

